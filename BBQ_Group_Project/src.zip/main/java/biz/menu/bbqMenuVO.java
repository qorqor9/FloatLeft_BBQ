package biz.menu;

public class bbqMenuVO {
	// 멤버변수
	private int menuno;
	private String menu;
	private String img;
	private String price;
	private String category;
	private String info;
	private String allergy;
	private double nutri1;
	private double nutri2;
	private double nutri3;
	private double nutri4;
	private double nutri5;
	private String origin;
	
	// 디폴트 생성자
	public bbqMenuVO() {}
	
	// getter, setter
	public int getMenuno() {
		return menuno;
	}
	public void setMenuno(int menuno) {
		this.menuno = menuno;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getAllergy() {
		return allergy;
	}
	public void setAllergy(String allergy) {
		this.allergy = allergy;
	}
	public double getNutri1() {
		return nutri1;
	}
	public void setNutri1(double nutri1) {
		this.nutri1 = nutri1;
	}
	public double getNutri2() {
		return nutri2;
	}
	public void setNutri2(double nutri2) {
		this.nutri2 = nutri2;
	}
	public double getNutri3() {
		return nutri3;
	}
	public void setNutri3(double nutri3) {
		this.nutri3 = nutri3;
	}
	public double getNutri4() {
		return nutri4;
	}
	public void setNutri4(double nutri4) {
		this.nutri4 = nutri4;
	}
	public double getNutri5() {
		return nutri5;
	}
	public void setNutri5(double nutri5) {
		this.nutri5 = nutri5;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	
}
